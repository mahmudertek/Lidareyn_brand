// ============================================
// KATEGORI VERİLERİ - RESELS E-TİCARET
// ============================================

const categoriesData = {
    'nalbur-yapi-malzemeleri': {
        title: 'Nalbur & Yapı Malzemeleri',
        description: 'Profesyonel nalbur malzemeleri ve yapı ürünleri. El aletleri, vida, çivi, silikon ve tamir malzemeleri uygun fiyatlarla Resels\'de.',
        icon: 'fa-hammer',
        subcategories: [
            { name: 'El Aletleri', items: ['Çekiç', 'Pense', 'Tornavida'], icon: 'fa-wrench' },
            { name: 'Bağlantı Elemanları', items: ['Çivi', 'Vida', 'Dübel'], icon: 'fa-screwdriver' },
            { name: 'Yapıştırıcılar & Bantlar', items: ['Koli Bandı', 'Çift Taraflı Bant', 'Yapıştırıcılar'], icon: 'fa-tape' },
            { name: 'Silikon & Mastik Ürünleri', items: ['Silikon Tabancası', 'Silikon', 'Mastik'], icon: 'fa-fill-drip' },
            { name: 'Kesici Aletler', items: ['Maket Bıçağı', 'Testere', 'Kesici'], icon: 'fa-cut' },
            { name: 'Kapı & Pencere Aksesuarları', items: ['Menteşe', 'Kol', 'Kilit'], icon: 'fa-door-open' },
            { name: 'Tamir & Bakım Malzemeleri', items: ['Tamir Kiti', 'Yedek Parça', 'Bakım Ürünleri'], icon: 'fa-toolbox' }
        ]
    },
    'hirdavat-teknik-malzemeler': {
        title: 'Hırdavat & Teknik Malzemeler',
        description: 'Hırdavat ve teknik malzemeler. Elektrik, tesisat, boya ekipmanları ve profesyonel el aletleri en uygun fiyatlarla.',
        icon: 'fa-screwdriver-wrench',
        subcategories: [
            { name: 'Profesyonel El Aletleri', items: ['Tornavida Seti', 'Pense Seti', 'Anahtar Seti'], icon: 'fa-toolbox' },
            { name: 'Elektrik Malzemeleri', items: ['Priz', 'Anahtar', 'Kablo'], icon: 'fa-plug' },
            { name: 'Su Tesisatı Ürünleri', items: ['Boru', 'Vana', 'Conta'], icon: 'fa-faucet' },
            { name: 'Boya & Boya Ekipmanları', items: ['Fırça', 'Rulo', 'Boya Kabı'], icon: 'fa-paint-roller' },
            { name: 'Bahçe El Aletleri', items: ['Kürek', 'Tırmık', 'Makas'], icon: 'fa-seedling' }
        ]
    },
    'ev-gerecleri-zuccaciye': {
        title: 'Ev Gereçleri & Züccaciye',
        description: 'Kaliteli ev gereçleri ve züccaciye ürünleri. Mutfak, banyo ve saklama çözümleri için geniş ürün yelpazesi.',
        icon: 'fa-kitchen-set',
        subcategories: [
            { name: 'Mutfak Ürünleri', items: ['Tencere', 'Tava', 'Bıçak Seti'], icon: 'fa-utensils' },
            { name: 'Saklama & Düzenleme', items: ['Saklama Kabı', 'Organizer', 'Sepet'], icon: 'fa-box' },
            { name: 'Termos & Matara', items: ['Termos', 'Matara', 'Sürahi'], icon: 'fa-bottle-water' },
            { name: 'Banyo Gereçleri', items: ['Sabunluk', 'Diş Fırçalığı', 'Havluluk'], icon: 'fa-bath' }
        ]
    },
    'evcil-hayvan-urunleri': {
        title: 'Evcil Hayvan Ürünleri',
        description: 'Evcil hayvanlarınız için kaliteli ürünler. Mama kapları, oyuncaklar, tasmalar ve bakım malzemeleri uygun fiyatlarla.',
        icon: 'fa-paw',
        subcategories: [
            { name: 'Mama & Su Kapları', items: ['Mama Kabı', 'Su Kabı', 'Otomatik Mama Kabı'], icon: 'fa-bowl-food' },
            { name: 'Oyuncaklar', items: ['Çiğneme Oyuncağı', 'Top', 'İnteraktif Oyuncak'], icon: 'fa-baseball' },
            { name: 'Tasma & Gezdirme', items: ['Tasma', 'Gezdirme Kayışı', 'Göğüs Tasması'], icon: 'fa-link' },
            { name: 'Temizlik & Bakım', items: ['Şampuan', 'Tırnak Makası', 'Fırça'], icon: 'fa-shower' }
        ]
    },
    'ev-yasam': {
        title: 'Ev & Yaşam',
        description: 'Evinizi güzelleştiren dekoratif ürünler. LED aydınlatma, organizer ve ev tekstili ürünleri Resels\'de.',
        icon: 'fa-house',
        subcategories: [
            { name: 'Dekoratif Aksesuarlar', items: ['Vazo', 'Çerçeve', 'Biblo'], icon: 'fa-star' },
            { name: 'LED Aydınlatma', items: ['LED Ampul', 'LED Şerit', 'Gece Lambası'], icon: 'fa-lightbulb' },
            { name: 'Organizerler', items: ['Raf Organizer', 'Dolap Organizer', 'Çekmece Düzenleyici'], icon: 'fa-table-cells' },
            { name: 'Minder & Tekstil', items: ['Minder', 'Yastık', 'Örtü'], icon: 'fa-couch' }
        ]
    },
    'temizlik-hijyen': {
        title: 'Temizlik & Hijyen',
        description: 'Temizlik ve hijyen ürünleri. Mop, bez, sünger ve doğal temizlik malzemeleri en uygun fiyatlarla.',
        icon: 'fa-spray-can-sparkles',
        subcategories: [
            { name: 'Mop & Temizlik Aparatları', items: ['Mop', 'Süpürge', 'Faraş'], icon: 'fa-broom' },
            { name: 'Bez & Sünger', items: ['Mikrofiber Bez', 'Sünger', 'Temizlik Bezi'], icon: 'fa-sponge' },
            { name: 'Doğal Temizlik Ürünleri', items: ['Ekolojik Deterjan', 'Sirke', 'Karbonat'], icon: 'fa-leaf' }
        ]
    },
    'kirtasiye-ofis': {
        title: 'Kırtasiye & Ofis Malzemeleri',
        description: 'Kırtasiye ve ofis malzemeleri. Kalem, defter, dosyalama ürünleri ve masaüstü organizerleri.',
        icon: 'fa-pen',
        subcategories: [
            { name: 'Yazı Gereçleri', items: ['Kalem', 'Defter', 'Not Kağıdı'], icon: 'fa-pencil' },
            { name: 'Dosyalama Ürünleri', items: ['Klasör', 'Dosya', 'Arşiv Kutusu'], icon: 'fa-folder' },
            { name: 'Masaüstü Düzenleyiciler', items: ['Kalemlik', 'Evrak Rafı', 'Organizer'], icon: 'fa-desktop' }
        ]
    },
    'elektronik-aksesuar': {
        title: 'Elektronik Aksesuar',
        description: 'Elektronik aksesuar ve telefon aksesuarları. Kılıf, şarj kablosu, Bluetooth hoparlör ve LED şerit ürünleri.',
        icon: 'fa-mobile-screen',
        subcategories: [
            { name: 'Telefon Kılıfları', items: ['Silikon Kılıf', 'Deri Kılıf', 'Şeffaf Kılıf'], icon: 'fa-mobile' },
            { name: 'Şarj Kabloları', items: ['USB-C Kablo', 'Lightning Kablo', 'Micro USB'], icon: 'fa-charging-station' },
            { name: 'Bluetooth Hoparlörler', items: ['Mini Hoparlör', 'Taşınabilir Hoparlör', 'Su Geçirmez Hoparlör'], icon: 'fa-volume-high' },
            { name: 'LED Şerit & Aydınlatma', items: ['RGB LED Şerit', 'Tek Renk LED', 'Akıllı LED'], icon: 'fa-lightbulb' }
        ]
    }
};

// Kategori listesini döndür
function getAllCategories() {
    return Object.keys(categoriesData).map(slug => ({
        slug: slug,
        ...categoriesData[slug]
    }));
}

// Belirli bir kategoriyi getir
function getCategoryBySlug(slug) {
    return categoriesData[slug] || null;
}
